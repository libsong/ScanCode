#ifndef __USER_SCAN_H__
#define __USER_SCAN_H__

extern void scanCamera(void);
#endif


